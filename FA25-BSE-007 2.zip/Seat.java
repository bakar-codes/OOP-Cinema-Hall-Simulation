public class Seat {
    String seatId;
    int row;
    String type;
    double price;
    boolean booked;
    public Seat(String seatId,int row,String type,double price) {
        this.seatId=seatId;
        this.row=row;
        this.type=type;
        this.price=price;
        this.booked=false;
    }
    public boolean bookSeat() {
        if (!booked) {
            booked=true;
            return true;
        }
        return false;
    }
    public String toString() {
        return booked?"X":" ";
    }
}