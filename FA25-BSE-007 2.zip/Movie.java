public class Movie {
    String title;
    String genre;
    int duration;
    String showTime;
    public Movie(String title,String genre,int duration,String showTime) {
        this.title=title;
        this.genre=genre;
        this.duration=duration;
        this.showTime=showTime;
    }
    public String toString() {
        return title + " (" + genre + ")";
    }
}