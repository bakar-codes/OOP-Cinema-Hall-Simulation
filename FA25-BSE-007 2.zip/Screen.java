public class Screen {
    String id;
    String type;
    Movie movie;
    Seat[][] seats;
    public Screen(String id,String type) {
        this.id=id;
        this.type=type;
        seats=new Seat[6][12];
        for (int r=0;r<6;r++) {
            String stype;
            double price;
            if (r<=1) {
                stype="Regular";
                price=150;
            } else if (r<=4) {
                stype="Premium";
                price=250;
            } else {
                stype="VIP";
                price=350;
            }
            for (int c=0;c<12;c++) {
                String seatId=stype.charAt(0)+ "" +(r+1)+(c+1);
                seats[r][c]=new Seat(seatId,r+1,stype,price);
            }
        }
    }
    public void setMovie(Movie m) {
        movie=m;
    }
    public boolean bookSeat(int r,int c) {
        if (r>0&&r<=6&&c>0&&c<=12) {
            return seats[r-1][c-1].bookSeat();
        }
        return false;
    }
    public void show(){
        System.out.println("\nScreen "+id+" ("+type+")");
        if (movie!=null) System.out.println("Movie: " + movie);
        System.out.println("SCREEN");
        for (int r=0;r<6;r++) {
            System.out.print("Row " + (r+1) + " " + seats[r][0].type + " Rs" + (int)seats[r][0].price + ": ");
            for (int c=0;c<12;c++) {
                System.out.print(seats[r][c] + " ");
            }
            System.out.println();
        }
    }
}