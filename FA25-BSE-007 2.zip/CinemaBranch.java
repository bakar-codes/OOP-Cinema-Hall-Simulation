public class CinemaBranch {
    String name;
    String city;
    Screen[] screens;
    int screenCount;
    public CinemaBranch(String name,String city) {
        this.name=name;
        this.city=city;
        screens=new Screen[5];
        screenCount=0;
    }
    public void addScreen(Screen s) {
        if (screenCount<5) {
            screens[screenCount++]=s;
        }
    }
    public void show() {
        System.out.println("\n" + name + " - " + city);
        System.out.println("Screens: " + screenCount);
        for (int i=0;i<screenCount;i++) {
            System.out.println("  " + screens[i].id);
        }
    }
}