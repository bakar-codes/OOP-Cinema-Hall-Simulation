public class Demo {
    public static void main(String[] args) {
        Company company=new Company("StarCinema");
        Movie avengers=new Movie("Avengers", "Action", 120, "18:00");
        Movie titanic=new Movie("Titanic", "Drama", 180, "20:00");
        Movie dune=new Movie("Dune", "SciFi", 155, "21:00");
        CinemaBranch lahore=new CinemaBranch("Lahore Mall", "Lahore");
        CinemaBranch islamabad=new CinemaBranch("Islamabad Plaza", "Islamabad");
        Screen s1=new Screen("S1", "IMAX");
        Screen s2=new Screen("S2", "3D");
        Screen s3=new Screen("S3", "2D");
        s1.setMovie(avengers);
        s2.setMovie(titanic);
        s3.setMovie(dune);
        lahore.addScreen(s1);
        lahore.addScreen(s2);
        islamabad.addScreen(s3);
        company.addBranch(lahore);
        company.addBranch(islamabad);
        company.show();
        System.out.println("\n=== All Screens ===");
        s1.show();
        s2.show(); 
        s3.show();
        System.out.println("\n=== Lahore IMAX Booking ===");
        s1.bookSeat(1, 2);
        s1.bookSeat(3, 5);
        s1.bookSeat(6, 10);
        s1.show();
    }
}