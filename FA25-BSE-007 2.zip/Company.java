public class Company {
    String name;
    CinemaBranch[] branches;
    int branchCount;
    public Company(String name) {
        this.name=name;
        branches=new CinemaBranch[5];
        branchCount=0;
    }
    public void addBranch(CinemaBranch b) {
        if (branchCount<5) {
            branches[branchCount++]=b;
        }
    }
    public void show(){
        System.out.println(name);
        System.out.println("Branches: " + branchCount);
        for (int i=0;i<branchCount;i++) {
            branches[i].show();
        }
    }
}